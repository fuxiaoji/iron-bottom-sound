# tests/

These are verbatim copies of the six test files added by CD-1..CD-6
(108 test cases).  In the repository they live in `tests/` and import
`iron_bottom_sound` from `backend/src` via the pytest `pythonpath` setting.

```bash
cp tests/test_command_delay_*.py <repo>/tests/
cd <repo> && .venv/bin/python -m pytest tests/test_command_delay_*.py -q
```

Coverage per file is listed in `../TEST_MANIFEST.md`.
