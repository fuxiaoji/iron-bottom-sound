# tests/

这些是本批次新增的八个测试文件（31 项），在仓库中位于 `tests/`，通过 pytest 的 `pythonpath = backend/src` 导入引擎。

```bash
cp tests/test_command_delay_*_v23.py <repo>/tests/ && cd <repo> && \
  .venv/bin/python -m pytest tests/test_command_delay_*_v23.py -q
```

逐文件覆盖见 `../TEST_MANIFEST.md`。
