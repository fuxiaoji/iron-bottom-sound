# battle_v2_3/

完整记录（battle_data.json、calls.jsonl、orders.jsonl、reports.jsonl、views/）留在仓库内 `research/command_delay/battle_v2_3/`，未复制进 zip（体积与可重演性考虑：指令批次 + 模型回复可逐阶段重演）。
本目录只放核验结果与战报。
