# code_patch/

`v2_3_repair.patch` 相对本批次基线提交 `e3149c4f3c147c966efba49908fc960f3a439278`，覆盖：

```
backend/src/iron_bottom_sound/command_delay.py backend/src/iron_bottom_sound/command_observation.py backend/src/iron_bottom_sound/communications/ backend/src/iron_bottom_sound/formation_agents.py backend/src/iron_bottom_sound/formation_llm.py backend/src/iron_bottom_sound/formation_maneuver.py backend/src/iron_bottom_sound/formation_memory.py backend/src/iron_bottom_sound/formation_knowledge.py backend/src/iron_bottom_sound/fleet_llm.py backend/src/iron_bottom_sound/reporting.py backend/src/iron_bottom_sound/claims.py backend/src/iron_bottom_sound/target_priority.py backend/src/iron_bottom_sound/delegation.py backend/src/iron_bottom_sound/research_hooks.py backend/src/iron_bottom_sound/models.py backend/src/iron_bottom_sound/engine.py backend/src/iron_bottom_sound/realistic_command.py tests/ research/command_delay/*.py research/command_delay/v2_3/*.py research/battle_video/*.py
```

应用：

```bash
git checkout e3149c4f3c147c966efba49908fc960f3a439278
git apply --stat code_patch/v2_3_repair.patch
git apply       code_patch/v2_3_repair.patch
```

注意：patch 不含 `research/command_delay/v2_3/raw/battle_em01/`（旧证据副本，已在 .gitignore 中）与对局大记录。
